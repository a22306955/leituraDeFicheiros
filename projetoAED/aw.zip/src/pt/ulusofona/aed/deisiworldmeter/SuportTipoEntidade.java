package pt.ulusofona.aed.deisiworldmeter;

public class SuportTipoEntidade {
    // 9.52
}
